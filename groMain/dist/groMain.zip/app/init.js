import initializeWidget from './main'
$(document).ready(function () {
  initializeWidget()
})
