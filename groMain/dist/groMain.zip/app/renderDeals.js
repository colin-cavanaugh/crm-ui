function renderDeals(relatedDeals) {
  console.log('renderDeals Function:', relatedDeals)
}
