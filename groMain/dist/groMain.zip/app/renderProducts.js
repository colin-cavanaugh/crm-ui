function renderProducts(relatedProducts) {
  console.log('This is from the function:', relatedProducts)
}
